1:"$Sreact.fragment"
2:I[3955,["711","static/chunks/8e1d74a4-69128d60206d0445.js","995","static/chunks/995-51c78640e6e57c5d.js","177","static/chunks/app/layout-a802a2c7f17e40cc.js"],"default"]
3:I[7555,[],""]
4:I[1295,[],""]
5:I[2548,["711","static/chunks/8e1d74a4-69128d60206d0445.js","995","static/chunks/995-51c78640e6e57c5d.js","177","static/chunks/app/layout-a802a2c7f17e40cc.js"],"default"]
6:I[894,[],"ClientPageRoot"]
7:I[9678,["711","static/chunks/8e1d74a4-69128d60206d0445.js","995","static/chunks/995-51c78640e6e57c5d.js","766","static/chunks/766-5350f741d307a6c9.js","58","static/chunks/58-f663254de46197b4.js","974","static/chunks/app/page-d93341a32b6aa932.js"],"default"]
a:I[9665,[],"OutletBoundary"]
d:I[9665,[],"ViewportBoundary"]
f:I[9665,[],"MetadataBoundary"]
11:I[6614,[],""]
:HL["/_next/static/media/a34f9d1faa5f3315-s.p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/css/68965ea2b8aa78ee.css","style"]
:HL["/_next/static/css/63c7182515913e2f.css","style"]
0:{"P":null,"b":"wdY71kAJ2XbDx9IpWmkkT","p":"","c":["",""],"i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/68965ea2b8aa78ee.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"ar","dir":"rtl","children":["$","body",null,{"className":"__className_d65c78","children":[["$","$L2",null,{}],["$","main",null,{"className":"min-h-screen pt-16","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L5",null,{}]]}]}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L6",null,{"Component":"$7","searchParams":{},"params":{},"promises":["$@8","$@9"]}],"$undefined",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/63c7182515913e2f.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","$La",null,{"children":["$Lb","$Lc",null]}]]}],{},null,false]},null,false],["$","$1","h",{"children":[null,["$","$1","D5Wlywv6FcdQYusK6ApcF",{"children":[["$","$Ld",null,{"children":"$Le"}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],["$","$Lf",null,{"children":"$L10"}]]}],false]],"m":"$undefined","G":["$11","$undefined"],"s":false,"S":true}
8:{}
9:{}
e:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
b:null
c:null
10:[["$","title","0",{"children":"متجر الملابس الطبية"}],["$","meta","1",{"name":"description","content":"متجر متخصص لبيع الملابس الطبية للعاملين في المجال الطبي"}],["$","link","2",{"rel":"icon","href":"/favicon.ico","type":"image/x-icon","sizes":"16x16"}]]
